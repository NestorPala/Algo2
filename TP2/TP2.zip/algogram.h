#include <stdio.h>

// NO ES UN TDA

// Permite iniciar el funcionamiento de la red social
// Pre: el archivo de usuarios es válido.
void algogram(FILE* usuarios);
